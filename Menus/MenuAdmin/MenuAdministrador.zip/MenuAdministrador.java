package Menus.MenuAdmin;

import Enum.RolEnum;
import Enum.VehiculoEnum;
import GestorPersonas.AyudantePromocion;
import GestorPersonas.GestorPersonas;
import GestorPersonas.Personas.Administrador;
import GestorPersonas.Personas.Persona;
import GestorPersonas.Personas.Usuario;
import GestorVehiculos.GestorVehiculos;
import GestorVehiculos.Mapa.Base;
import GestorVehiculos.Mapa.Mapa;
import GestorVehiculos.Vehiculos.MotoGrande;
import GestorVehiculos.Vehiculos.MotoPequena;
import GestorVehiculos.Vehiculos.Vehiculo;
import GestorVehiculos.Vehiculos.VehiculoDeBase;
import GestorViajes.Beneficios;
import GestorViajes.Descuentos;
import GestorViajes.GestorViajes;
import GestorViajes.Tarifas;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class MenuAdministrador {

    //=================================================
    // ATRIBUTOS
    //=================================================
    private GestorPersonas gestorPersonas;
    private GestorVehiculos gestorVehiculos;
    private GestorViajes gestorViajes;

    //=================================================
    // CONSTRUCTOR
    //=================================================
    public MenuAdministrador(GestorPersonas gestorPersonas, GestorVehiculos gestorVehiculos, GestorViajes gestorViajes) {
        this.gestorViajes = gestorViajes;
        this.gestorVehiculos = gestorVehiculos;
        this.gestorPersonas = gestorPersonas;
    }

    //=================================================
    // MENÚ PRINCIPAL
    //=================================================
    public void mostrarMenu(Administrador administrador) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n========== MENÚ ADMINISTRADOR ==========");
            System.out.println("Usuario: " + administrador.getNombre() + " " + administrador.getApellidos());
            
            System.out.println("\n1. Gestión de Personas");
            System.out.println("2. Gestión de Vehículos");
            System.out.println("3. Gestión de Bases");
            System.out.println("4. Gestión de Viajes y Tarifas");
            System.out.println("5. Gestión de Empleados");
            System.out.println("6. Consultas y Visualización");
            System.out.println("7. Cerrar Sesión");
            
            System.out.print("\nSeleccione opción: ");
            
            int opcion = leerEntero(scanner);
            
            try {
                switch (opcion) {
                    case 1 -> menuGestionPersonas(scanner, administrador);
                    case 2 -> menuGestionVehiculos(scanner);
                    case 3 -> menuGestionBases(scanner);
                    case 4 -> menuGestionViajesYTarifas(scanner);
                    case 5 -> menuGestionEmpleados(scanner);
                    case 6 -> menuConsultas(scanner);
                    case 7 -> {
                        System.out.println("Cerrando sesión...");
                        return;
                    }
                    default -> System.out.println("Opción no válida. Por favor, selecciona una opción del menú.");
                }
            } catch (UnsupportedOperationException e) {
                System.out.println("Esta funcionalidad aún no está implementada: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    //=================================================
    // SUBMENÚS PRINCIPALES
    //=================================================
    
    private void menuGestionPersonas(Scanner scanner, Administrador administrador) {
        MenuGestionPersonas menuGestionPersonas = new MenuGestionPersonas(gestorPersonas, gestorViajes, new UtilsMenu());
        menuGestionPersonas.mostrarMenu(scanner);
    }

    private void menuGestionVehiculos(Scanner scanner) {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n========== GESTIÓN DE VEHÍCULOS ==========");
            System.out.println("1. Alta Vehículo en Almacén");
            System.out.println("2. Alta Vehículo en Mapa (Motos)");
            System.out.println("3. Alta Vehículo en Base (Bicicletas/Patinetes)");
            System.out.println("4. Baja Vehículo");
            System.out.println("5. Reubicar Vehículos");
            System.out.println("6. Mover Vehículo desde Almacén");
            System.out.println("7. Volver al menú principal");
            
            System.out.print("\nSeleccione opción: ");
            int opcion = leerEntero(scanner);
            
            try {
                switch (opcion) {
                    case 1 -> altaVehiculoAlmacen(scanner);
                    case 2 -> altaVehiculoMapa(scanner);
                    case 3 -> altaVehiculoBase(scanner);
                    case 4 -> bajaVehiculo(scanner);
                    case 5 -> menuReubicarVehiculos(scanner);
                    case 6 -> moverVehiculoDesdeAlmacen(scanner);
                    case 7 -> volver = true;
                    default -> System.out.println("Opción no válida. Por favor, selecciona una opción del menú.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void menuGestionBases(Scanner scanner) {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n========== GESTIÓN DE BASES ==========");
            System.out.println("1. Alta Base Manual");
            System.out.println("2. Alta Base Automática");
            System.out.println("3. Visualizar Mapa");
            System.out.println("4. Volver al menú principal");
            
            System.out.print("\nSeleccione opción: ");
            int opcion = leerEntero(scanner);
            
            try {
                switch (opcion) {
                    case 1 -> altaBase();
                    case 2 -> altaBaseAutomatica(scanner);
                    case 3 -> dibujarMapa(scanner);
                    case 4 -> volver = true;
                    default -> System.out.println("Opción no válida. Por favor, selecciona una opción del menú.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void menuGestionViajesYTarifas(Scanner scanner) {
        MenuGestionViajesYTarifas menuGestionViajesYTarifas = new MenuGestionViajesYTarifas(gestorViajes, new UtilsMenu());
        menuGestionViajesYTarifas.mostrarMenu(scanner);
    }

    private void menuGestionEmpleados(Scanner scanner) {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n========== GESTIÓN DE EMPLEADOS ==========");
            System.out.println("1. Asignar Vehículos a Personal de Mantenimiento");
            System.out.println("2. Asignar Vehículos a Mecánico");
            System.out.println("3. Asignar Base a Mecánico");
            System.out.println("4. Volver al menú principal");
            
            System.out.print("\nSeleccione opción: ");
            int opcion = leerEntero(scanner);
            
            try {
                switch (opcion) {
                    case 1 -> asignarVehiculoMantenimiento(scanner);
                    case 2 -> asignarVehiculoMecanico(scanner);
                    case 3 -> asignarBaseMecanico(scanner);
                    case 4 -> volver = true;
                    default -> System.out.println("Opción no válida. Por favor, selecciona una opción del menú.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void menuConsultas(Scanner scanner) {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n========== CONSULTAS Y VISUALIZACIÓN ==========");
            System.out.println("1. Listar Personas");
            System.out.println("2. Buscar Personas");
            System.out.println("3. Estado de Vehículos");
            System.out.println("4. Listar Vehículos");
            System.out.println("5. Listar Viajes");
            System.out.println("6. Estadísticas de Uso");
            System.out.println("7. Estado de Bases");
            System.out.println("8. Listar Bases");
            System.out.println("9. Volver al menú principal");
            
            System.out.print("\nSeleccione opción: ");
            int opcion = leerEntero(scanner);
            
            try {
                switch (opcion) {
                    case 1 -> mostrarPersonas(scanner);
                    case 2 -> buscarPersonas(scanner);
                    case 3 -> visualizarEstadoVehiculos(scanner);
                    case 4 -> mostrarVehiculos(scanner);
                    case 5 -> mostrarViajes();
                    case 6 -> visualizarEstadisticasUso(scanner);
                    case 7 -> visualizarEstadoBases(scanner);
                    case 8 -> mostrarBases(scanner);
                    case 9 -> volver = true;
                    default -> System.out.println("Opción no válida. Por favor, selecciona una opción del menú.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void menuReubicarVehiculos(Scanner scanner) {
        System.out.println("\n=== REUBICAR VEHÍCULOS ===");
        System.out.println("1. Mover moto a nuevas coordenadas");
        System.out.println("2. Mover bicicleta/patinete a nueva base");
        System.out.println("3. Distribución automática de vehículos almacenados");
        System.out.println("4. Volver al menú anterior");
        
        System.out.print("\nSeleccione una opción: ");
        int opcion = leerEntero(scanner);
        
        switch (opcion) {
            case 1:
                moverMotoACoordenadas(scanner);
                break;
            case 2:
                moverVehiculoANuevaBase(scanner);
                break;
            case 3:
                ubicarVehiculosAlmacenadosEficientemente(scanner);
                break;
            case 4:
                return;
            default:
                System.out.println("Opción no válida.");
        }
    }
    
    //=================================================
    // GESTIÓN DE PERSONAS
    //=================================================
    
    private void altaUsuario(Scanner scanner) {
        System.out.print("Introduce el nombre del nuevo registro: ");
        String nombre = scanner.next();
        System.out.print("Introduce los apellidos del nuevo registro: ");
        String apellidos = scanner.next();
        System.out.print("Introduce el DNI del nuevo registro (8 números seguidos de una letra mayúscula): ");
        String dniInput = scanner.next();
        
        // Formatear el DNI
        String dni = formatearDNI(dniInput);
        if (dni == null) {
            System.out.println("Error: Formato de DNI incorrecto. Debe contener 8 dígitos y una letra.");
            return;
        }
        
        RolEnum rolEnum = seleccionarRol(scanner);
        gestorPersonas.addPersona(nombre, apellidos, dni, rolEnum);
    }

    private void bajaUsuario(Scanner scanner) {
        System.out.println("\n=== Usuarios disponibles en el sistema ===");
        for (Persona persona : gestorPersonas.getPersonas()) {
            System.out.printf("DNI: %s - %s %s (%s)\n", 
                persona.getDNI(), persona.getNombre(), 
                persona.getApellidos(), persona.getRol());
        }
        
        System.out.print("\nIntroduce el DNI del usuario a eliminar: ");
        String dniInput = scanner.next();
        
        // Formatear el DNI
        String dni = formatearDNI(dniInput);
        if (dni == null) {
            System.out.println("Error: Formato de DNI incorrecto. Debe contener 8 dígitos y una letra.");
            return;
        }
        
        gestorPersonas.removePersona(dni);
    }

    private void modificarUsuario(Scanner scanner) {
        System.out.print("Introduce el DNI del usuario a modificar (8 números seguidos de una letra mayúscula): ");
        String dniInput = scanner.next();
        
        // Formatear el DNI
        String dni = formatearDNI(dniInput);
        if (dni == null) {
            System.out.println("Error: Formato de DNI incorrecto. Debe contener 8 dígitos y una letra.");
            return;
        }
        
        if (!gestorPersonas.existeDNI(dni)) {
            System.out.println("Error: El DNI no existe. Operación cancelada.");
            return;
        }
        
        Persona persona = gestorPersonas.getPersonaPorDNI(dni);
        System.out.println("\nDatos actuales del usuario:");
        System.out.println("Nombre: " + persona.getNombre());
        System.out.println("Apellidos: " + persona.getApellidos());
        System.out.println("Rol actual: " + persona.getRol());
        
        // Guardar si el usuario era Premium antes de modificarlo
        boolean eraPremium = persona.getRol() == RolEnum.USUARIO_PREMIUM;
        
        System.out.print("\nIntroduce el nuevo nombre: ");
        String nuevoNombre = scanner.next();
        System.out.print("Introduce los nuevos apellidos: ");
        String nuevosApellidos = scanner.next();

        RolEnum rolEnum = seleccionarRol(scanner);
        
        // Si era Premium y ahora seleccionaron USUARIO_STANDARD, mantenerlo como Premium
        if (eraPremium && rolEnum == RolEnum.USUARIO_STANDARD) {
            System.out.println("El usuario era Premium. Se mantendrá como USUARIO_PREMIUM.");
            rolEnum = RolEnum.USUARIO_PREMIUM;
        }
        gestorPersonas.modificarPersona(dni, nuevoNombre, nuevosApellidos,  rolEnum);
    }
    
    private void mostrarUsuariosPromocion(Scanner scanner) {
        System.out.println("\n===== USUARIOS QUE CUMPLEN CONDICIONES PARA PROMOCIÓN =====");
        AyudantePromocion ayudante = AyudantePromocion.getInstancia();
        ayudante.mostrarUsuariosPromocion();
    }

    private void modificarEstadoUsuario(Scanner scanner) {
        System.out.println("\n--- Modificar Estado de Usuario (Standard/Premium) ---");
        System.out.print("Introduce el DNI del usuario (8 números seguidos de una letra mayúscula): ");
        String dniInput = scanner.next();
        
        // Formatear el DNI
        String dni = formatearDNI(dniInput);
        if (dni == null) {
            System.out.println("Error: Formato de DNI incorrecto. Debe contener 8 dígitos y una letra.");
            return;
        }
        
        // Verificar que el usuario existe y es un usuario (no administrador, etc.)
        if (!gestorPersonas.existeDNI(dni)) {
            System.out.println("Error: No existe ningún usuario con el DNI proporcionado.");
            return;
        }
        Persona persona = gestorPersonas.getPersonaPorDNI(dni);
        if (!(persona instanceof Usuario)) {
            System.out.println("Error: El DNI proporcionado no corresponde a un usuario.");
            return;
        }
        Usuario usuario = (Usuario) persona;
        boolean esPremiumActualmente = usuario.getRol() == RolEnum.USUARIO_PREMIUM;
        
        // Mostrar información del usuario y su rol actual
        System.out.println("\nUsuario: " + usuario.getNombre() + " " + usuario.getApellidos());
        System.out.println("Rol actual: " + (esPremiumActualmente ? "PREMIUM" : "STANDARD"));
        
        if (esPremiumActualmente) {
            // Si es PREMIUM, solo puede convertirse a STANDARD
            System.out.println("¿Deseas convertir este usuario a STANDARD? (S/N): ");
            String respuesta = scanner.next().toUpperCase();
            if (respuesta.equals("S")) {
                if (gestorPersonas.cambiarRolUsuario(dni, false)) {
                    System.out.println("Usuario convertido a STANDARD exitosamente.");
                } else {
                    System.out.println("No se pudo modificar el estado del usuario.");
                }
            } else {
                System.out.println("Operación cancelada. El usuario sigue siendo PREMIUM.");
            }
        } else {
            // Si es STANDARD, verificar si cumple condiciones para ser PREMIUM
            AyudantePromocion ayudante = AyudantePromocion.getInstancia();
            // Obtener detalles de promoción del usuario
            Map<String, Object> infoUsuario = ayudante.obtenerDetallesPromocionUsuario(usuario);
            if (infoUsuario == null) {
                System.out.println("\nEl usuario NO cumple las condiciones necesarias para ser promovido a PREMIUM.");
                System.out.println("Para ser promovido, debe cumplir al menos una de estas condiciones:");
                System.out.println("- Al menos 15 viajes en el último mes");
                System.out.println("- Al menos 10 viajes mensuales durante 3 meses consecutivos");
                System.out.println("- Uso de todos los tipos de vehículos durante 6 meses consecutivos");
                return;
            }
            // El usuario cumple las condiciones, mostrar cuáles
            System.out.println("\nEl usuario CUMPLE las siguientes condiciones para promoción:");
            if ((boolean) infoUsuario.get("condicion1")) {
                System.out.println("- Al menos 15 viajes en el último mes (" + infoUsuario.get("viajesUltimoMes") + " viajes)");
            }
            if ((boolean) infoUsuario.get("condicion2")) {
                System.out.println("- Al menos 10 viajes mensuales durante 3 meses consecutivos");
            }
            if ((boolean) infoUsuario.get("condicion3")) {
                System.out.println("- Uso de todos los tipos de vehículos durante 6 meses consecutivos");
            }
            System.out.print("\n¿Deseas promover este usuario a PREMIUM? (S/N): ");
            String respuesta = scanner.next().toUpperCase();
            if (respuesta.equals("S")) {
                if (gestorPersonas.cambiarRolUsuario(dni, true)) {
                    System.out.println("Usuario promovido a PREMIUM exitosamente.");
                } else {
                    System.out.println("No se pudo modificar el estado del usuario.");
                }
            } else {
                System.out.println("Operación cancelada. El usuario sigue siendo STANDARD.");
            }
        }
    }

    private void buscarPersonas(Scanner scanner) {
        System.out.println("\n=== BÚSQUEDA DE PERSONAS ===");
        System.out.println("1. Buscar por DNI");
        System.out.println("2. Buscar por nombre");
        System.out.println("3. Filtrar por rol");
        System.out.println("4. Volver al menú anterior");
        
        System.out.print("\nSeleccione una opción: ");
        int opcion = leerEntero(scanner);
        
        switch (opcion) {
            case 1:
                buscarPersonaPorDNI(scanner);
                break;
            case 2:
                buscarPersonaPorNombre(scanner);
                break;
            case 3:
                filtrarPersonasPorRol(scanner);
                break;
            case 4:
                return;
            default:
                System.out.println("Opción no válida.");
        }
    }

    private void buscarPersonaPorDNI(Scanner scanner) {
        System.out.print("Introduce el DNI a buscar: ");
        String dniInput = scanner.next();
        String dni = formatearDNI(dniInput);
        if (dni == null) {
            System.out.println("Formato de DNI incorrecto.");
            return;
        }
        Persona persona = gestorPersonas.getPersonaPorDNI(dni);
        if (persona == null) {
            System.out.println("No se encontró ninguna persona con ese DNI.");
        } else {
            System.out.println("\nPersona encontrada:");
            mostrarDetallesPersona(persona);
        }
    }

    private void buscarPersonaPorNombre(Scanner scanner) {
        scanner.nextLine(); // Limpiar buffer
        System.out.print("Introduce el nombre o parte del nombre: ");
        String nombre = scanner.nextLine().toLowerCase();
        List<Persona> resultados = new ArrayList<>();
        
        for (Persona persona : gestorPersonas.getPersonas()) {
            if (persona.getNombre().toLowerCase().contains(nombre) || 
                persona.getApellidos().toLowerCase().contains(nombre)) {
                resultados.add(persona);
            }
        }
        
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron personas con ese nombre o apellido.");
        } else {
            System.out.println("\nSe encontraron " + resultados.size() + " resultados:");
            for (Persona persona : resultados) {
                mostrarDetallesPersona(persona);
                System.out.println("-------------------------");
            }
        }
    }

    private void filtrarPersonasPorRol(Scanner scanner) {
        System.out.println("Selecciona el rol a filtrar:");
        System.out.println("1. Usuarios estándar");
        System.out.println("2. Usuarios premium");
        System.out.println("3. Mecánicos");
        System.out.println("4. Personal de mantenimiento");
        System.out.println("5. Administradores");
        
        System.out.print("Introduce opción: ");
        int opcion = leerEntero(scanner);
        RolEnum rolFiltro;
        switch (opcion) {
            case 1 -> rolFiltro = RolEnum.USUARIO_STANDARD;
            case 2 -> rolFiltro = RolEnum.USUARIO_PREMIUM;
            case 3 -> rolFiltro = RolEnum.MECANICO;
            case 4 -> rolFiltro = RolEnum.MANTENIMIENTO;
            case 5 -> rolFiltro = RolEnum.ADMINISTRADOR;
            default -> {
                System.out.println("Opción no válida.");
                return;
            }
        }
        
        List<Persona> personasFiltradas = new ArrayList<>();
        for (Persona persona : gestorPersonas.getPersonas()) {
            if (persona.getRol() == rolFiltro) {
                personasFiltradas.add(persona);
            }
        }
        
        if (personasFiltradas.isEmpty()) {
            System.out.println("No se encontraron personas con el rol " + rolFiltro);
        } else {
            System.out.println("\nSe encontraron " + personasFiltradas.size() + " personas con rol " + rolFiltro + ":");
            for (Persona persona : personasFiltradas) {
                mostrarDetallesPersona(persona);
                System.out.println("-------------------------");
            }
        }
    }

    private void mostrarDetallesPersona(Persona persona) {
        System.out.println("DNI: " + persona.getDNI());
        System.out.println("Nombre: " + persona.getNombre() + " " + persona.getApellidos());
        System.out.println("Rol: " + persona.getRol());
        
        // Si es usuario, mostrar información adicional
        if (persona instanceof Usuario usuario) {
            System.out.println("Tipo: " + (usuario.getRol() == RolEnum.USUARIO_PREMIUM ? "Premium" : "Estándar"));
            System.out.println("Viajes realizados: " + gestorViajes.contarViajesPorUsuario(usuario.getDNI()));
        }
    }
    
    //=================================================
    // GESTIÓN DE VEHÍCULOS
    //=================================================
    
    private void altaVehiculoAlmacen(Scanner scanner) {
        System.out.println("\n--- Alta de Vehículo en Almacén ---");
        VehiculoEnum tipoVehiculo = seleccionarTipoVehiculo(scanner);
        if (tipoVehiculo != null) {
            gestorVehiculos.addVehiculo(tipoVehiculo);
        }
    }

    private void altaVehiculoMapa(Scanner scanner) {
        System.out.println("\n--- Alta de Moto en Posición del Mapa ---");
        // Seleccionar solo tipos de moto (Moto Pequeña o Moto Grande)
        System.out.println("Selecciona el tipo de moto:");
        System.out.println("1. Moto Pequeña");
        System.out.println("2. Moto Grande");
        System.out.print("Introduce una opción (1-2): ");
        int opcion = leerEntero(scanner);
        VehiculoEnum tipoMoto;
        switch (opcion) {
            case 1 -> tipoMoto = VehiculoEnum.MOTOPEQUENA;
            case 2 -> tipoMoto = VehiculoEnum.MOTOGRANDE;
            default -> {
                System.out.println("Opción no válida. Operación cancelada.");
                return;
            }
        }
        
        // Solicitar coordenadas
        System.out.println("\nIntroduce las coordenadas donde posicionar la moto:");
        System.out.print("Coordenada X: ");
        int x = leerEntero(scanner);
        System.out.print("Coordenada Y: ");
        int y = leerEntero(scanner);
        
        // Intentar añadir la moto en la posición especificada
        Vehiculo nuevoVehiculo = gestorVehiculos.addMotoEnPosicion(tipoMoto, x, y);
        if (nuevoVehiculo != null) {
            System.out.println("Moto añadida exitosamente. ID asignado: " + nuevoVehiculo.getID());
            // Mostrar el mapa actualizado
            Mapa mapa = Mapa.getInstancia();
            mapa.dibujarMapa();
        } else {
            System.out.println("No se pudo añadir la moto en la posición especificada.");
        }
    }

    private void altaVehiculoBase(Scanner scanner) {
        System.out.println("\n--- Alta de Vehículo en Base ---");
        // Seleccionar solo tipos para base (Bicicleta o Patinete)
        System.out.println("Selecciona el tipo de vehículo:");
        System.out.println("1. Bicicleta");
        System.out.println("2. Patinete");
        System.out.print("Introduce una opción (1-2): ");
        int opcion = leerEntero(scanner);
        VehiculoEnum tipoVehiculo;
        switch (opcion) {
            case 1 -> tipoVehiculo = VehiculoEnum.BICICLETA;
            case 2 -> tipoVehiculo = VehiculoEnum.PATINETE;
            default -> {
                System.out.println("Opción no válida. Operación cancelada.");
                return;
            }
        }
        
        // Mostrar las bases disponibles
        Mapa mapa = Mapa.getInstancia();
        List<Base> bases = mapa.getBases();
        if (bases.isEmpty()) {
            System.out.println("No hay bases disponibles en el sistema. Primero debe crear una base.");
            return;
        }
        
        System.out.println("\nBases disponibles:");
        for (Base base : bases) {
            System.out.println("- " + base.getNombre() + 
                              " (Coordenadas: " + base.getCoordenadaX() + ", " + base.getCoordenadaY() + 
                              ", Espacios libres: " + base.getEspaciosLibres() + ")");
        }
        
        // Solicitar el nombre de la base
        System.out.print("\nIntroduce el nombre de la base donde añadir el vehículo: ");
        scanner.nextLine(); // Limpiar buffer
        String nombreBase = scanner.nextLine();
        
        // Intentar añadir el vehículo en la base especificada
        Vehiculo nuevoVehiculo = gestorVehiculos.addVehiculoEnBase(tipoVehiculo, nombreBase);
        if (nuevoVehiculo != null) {
            System.out.println("Vehículo añadido exitosamente a la base. ID asignado: " + nuevoVehiculo.getID());
        } else {
            System.out.println("No se pudo añadir el vehículo a la base especificada.");
        }
    }

    private void bajaVehiculo(Scanner scanner) {
        System.out.println("\n--- Baja de Vehículo ---");
        
        System.out.println("\nVehículos disponibles:");
        for (Vehiculo vehiculo : gestorVehiculos.getTodosLosVehiculos()) {
            String ubicacion = determinarUbicacionVehiculo(vehiculo);
            System.out.printf("ID: %d - Tipo: %s - Ubicación: %s\n", 
                vehiculo.getID(), vehiculo.getTipoVehiculo(), ubicacion);
        }

        System.out.print("\nIntroduce el ID del vehículo a eliminar: ");
        int ID = leerEntero(scanner);
        gestorVehiculos.eliminarVehiculoPorID(ID);
    }

    private void modificarUbicacionVehiculo(Scanner scanner) {
        System.out.println("\n--- Modificar Ubicación de Vehículo ---");
        
        System.out.print("Introduce el ID del vehículo a reubicar: ");
        int idVehiculo = leerEntero(scanner);
        
        // Buscar el vehículo
        Vehiculo vehiculo = gestorVehiculos.obtenerPorID(idVehiculo);
        if (vehiculo == null) {
            System.out.println("No se encontró ningún vehículo con ID " + idVehiculo);
            return;
        }
        
        // Mostrar información del vehículo
        System.out.println("Vehículo encontrado:");
        System.out.println("- ID: " + vehiculo.getID());
        System.out.println("- Tipo: " + vehiculo.getTipoVehiculo());
        
        // Determinar acción según el tipo de vehículo
        if (vehiculo instanceof MotoPequena || vehiculo instanceof MotoGrande) {
            // Solicitar nuevas coordenadas
            System.out.println("Introduce las nuevas coordenadas para la moto:");
            System.out.print("Coordenada X: ");
            int nuevaX = leerEntero(scanner);
            
            System.out.print("Coordenada Y: ");
            int nuevaY = leerEntero(scanner);
            
            // Usar el nuevo método para mover la moto
            boolean resultado = gestorVehiculos.moverMotoANuevasPosicion(idVehiculo, nuevaX, nuevaY);
            
            if (resultado) {
                System.out.println("Moto reubicada exitosamente. Mostrando mapa actualizado:");
                Mapa mapa = Mapa.getInstancia();
                mapa.dibujarMapa();
            } else {
                System.out.println("No se pudo reubicar la moto a las nuevas coordenadas.");
            }
        } else if (vehiculo instanceof VehiculoDeBase) {
            // Mostrar bases disponibles
            Mapa mapa = Mapa.getInstancia();
            List<Base> bases = mapa.getBases();
            
            if (bases.isEmpty()) {
                System.out.println("No hay bases disponibles en el sistema.");
                return;
            }
            
            System.out.println("\nBases disponibles:");
            for (Base base : bases) {
                System.out.println("- " + base.getNombre() + 
                                 " (Coordenadas: " + base.getCoordenadaX() + ", " + base.getCoordenadaY() + 
                                 ", Espacios libres: " + base.getEspaciosLibres() + ")");
            }
            
            // Solicitar el nombre de la nueva base
            System.out.print("\nIntroduce el nombre de la nueva base para el vehículo: ");
            scanner.nextLine(); // Limpiar buffer
            String nombreBase = scanner.nextLine();
            
            // Usar el nuevo método para mover el vehículo
            boolean resultado = gestorVehiculos.moverVehiculoANuevaBase(idVehiculo, nombreBase);
            
            if (resultado) {
                System.out.println("Vehículo reubicado exitosamente en la base '" + nombreBase + "'");
            } else {
                System.out.println("No se pudo reubicar el vehículo a la base especificada.");
            }
        } else {
            System.out.println("Tipo de vehículo no reconocido para reubicación.");
        }
    }

    private void ubicarVehiculosAlmacenadosEficientemente(Scanner scanner) {
        gestorVehiculos.ubicarVehiculosAlmacenadosEficientemente();
    }

    private void moverMotoACoordenadas(Scanner scanner) {
        System.out.println("\n--- Mover Moto a Nuevas Coordenadas ---");
        
        // Listar motos disponibles en el mapa
        List<Vehiculo> motosEnMapa = gestorVehiculos.getVehiculosEnMapa();
        if (motosEnMapa.isEmpty()) {
            System.out.println("No hay motos disponibles en el mapa para mover.");
            return;
        }
        
        System.out.println("\nMotos disponibles en el mapa:");
        for (Vehiculo moto : motosEnMapa) {
            if (moto instanceof MotoPequena || moto instanceof MotoGrande) {
                System.out.println("ID: " + moto.getID() + 
                                 ", Tipo: " + moto.getTipoVehiculo() +
                                 ", Coordenadas: (" + moto.getCoordenadaX() + ", " + moto.getCoordenadaY() + ")" +
                                 ", Batería: " + moto.getBateria() + "%" +
                                 ", Averías: " + (moto.tieneAverias() ? "Sí" : "No"));
            }
        }
        
        // Solicitar ID de la moto a mover
        System.out.print("\nIntroduce el ID de la moto que deseas mover: ");
        int idMoto = leerEntero(scanner);
        
        // Solicitar nuevas coordenadas
        System.out.println("Introduce las nuevas coordenadas:");
        System.out.print("Coordenada X: ");
        int nuevaX = leerEntero(scanner);
        
        System.out.print("Coordenada Y: ");
        int nuevaY = leerEntero(scanner);
        
        // Intentar mover la moto
        boolean resultado = gestorVehiculos.moverMotoANuevasPosicion(idMoto, nuevaX, nuevaY);
        
        if (resultado) {
            System.out.println("Moto movida exitosamente. Mostrando mapa actualizado:");
            Mapa mapa = Mapa.getInstancia();
            mapa.dibujarMapa();
        } else {
            System.out.println("No se pudo mover la moto a las nuevas coordenadas.");
        }
    }

    private void moverVehiculoANuevaBase(Scanner scanner) {
        System.out.println("\n--- Mover Vehículo a Nueva Base ---");
        
        // Listar vehículos disponibles en bases
        List<Vehiculo> vehiculosEnBases = gestorVehiculos.getVehiculosEnBases();
        List<Vehiculo> vehiculosAlmacenados = gestorVehiculos.getVehiculosAlmacenados();
        
        boolean hayVehiculosParaMover = false;
        
        System.out.println("\nVehículos en bases disponibles para mover:");
        for (Vehiculo vehiculo : vehiculosEnBases) {
            if (vehiculo instanceof VehiculoDeBase) {
                Base baseActual = ((VehiculoDeBase) vehiculo).getBase();
                System.out.println("ID: " + vehiculo.getID() + 
                                 ", Tipo: " + vehiculo.getTipoVehiculo() +
                                 ", Base actual: " + (baseActual != null ? baseActual.getNombre() : "Sin base") +
                                 ", Batería: " + vehiculo.getBateria() + "%" +
                                 ", Averías: " + (vehiculo.tieneAverias() ? "Sí" : "No"));
                hayVehiculosParaMover = true;
            }
        }
        
        System.out.println("\nVehículos en almacén disponibles para mover:");
        for (Vehiculo vehiculo : vehiculosAlmacenados) {
            if (vehiculo instanceof VehiculoDeBase) {
                System.out.println("ID: " + vehiculo.getID() + 
                                 ", Tipo: " + vehiculo.getTipoVehiculo() +
                                 ", Ubicación: Almacén" +
                                 ", Batería: " + vehiculo.getBateria() + "%" +
                                 ", Averías: " + (vehiculo.tieneAverias() ? "Sí" : "No"));
                hayVehiculosParaMover = true;
            }
        }
        
        if (!hayVehiculosParaMover) {
            System.out.println("No hay bicicletas ni patinetes disponibles para mover.");
            return;
        }
        
        // Solicitar ID del vehículo a mover
        System.out.print("\nIntroduce el ID del vehículo que deseas mover: ");
        int idVehiculo = leerEntero(scanner);
        
        // Mostrar bases disponibles
        Mapa mapa = Mapa.getInstancia();
        List<Base> bases = mapa.getBases();
        if (bases.isEmpty()) {
            System.out.println("No hay bases disponibles en el sistema.");
            return;
        }
        
        System.out.println("\nBases disponibles:");
        for (Base base : bases) {
            System.out.println("- " + base.getNombre() + 
                             " (Coordenadas: " + base.getCoordenadaX() + ", " + base.getCoordenadaY() + 
                             ", Espacios libres: " + base.getEspaciosLibres() + ")");
        }
        
        // Solicitar nombre de la nueva base
        System.out.print("\nIntroduce el nombre de la base donde mover el vehículo: ");
        scanner.nextLine(); // Limpiar buffer
        String nombreBase = scanner.nextLine();
        
        // Intentar mover el vehículo
        boolean resultado = gestorVehiculos.moverVehiculoANuevaBase(idVehiculo, nombreBase);
                
        if (resultado) {
            System.out.println("Vehículo movido exitosamente a la nueva base.");
        } else {
            System.out.println("No se pudo mover el vehículo a la nueva base.");
        }
    }

    private void moverVehiculoDesdeAlmacen(Scanner scanner) {
        System.out.println("\n--- Mover Vehículo desde Almacén ---");
        
        // Listar vehículos almacenados
        List<Vehiculo> vehiculosAlmacenados = gestorVehiculos.getVehiculosAlmacenados();
        if (vehiculosAlmacenados.isEmpty()) {
            System.out.println("No hay vehículos disponibles en el almacén para mover.");
            return;
        }
        
        System.out.println("\nVehículos disponibles en el almacén:");
        for (Vehiculo vehiculo : vehiculosAlmacenados) {
            System.out.println("ID: " + vehiculo.getID() +
                             ", Tipo: " + vehiculo.getTipoVehiculo() +
                             ", Batería: " + vehiculo.getBateria() + "%" +
                             ", Averías: " + (vehiculo.tieneAverias() ? "Sí" : "No"));
        }
        
        // Solicitar ID del vehículo a mover
        System.out.print("\nIntroduce el ID del vehículo que deseas mover: ");
        int idVehiculo = leerEntero(scanner);
        
        // Buscar el vehículo en el almacén
        Vehiculo vehiculo = gestorVehiculos.obtenerPorID(idVehiculo);
        
        if (vehiculo == null || !vehiculosAlmacenados.contains(vehiculo)) {
            System.out.println("Error: No existe un vehículo con ese ID en el almacén.");
            return;
        }
        
        // Determinar el tipo de vehículo para saber dónde se puede mover
        if (vehiculo instanceof MotoPequena || vehiculo instanceof MotoGrande) {
            // Para motos, solicitar coordenadas en el mapa
            System.out.println("Este vehículo es una moto. Debe posicionarse en el mapa.");
            System.out.println("Introduce las coordenadas donde posicionar la moto:");
            System.out.print("Coordenada X: ");
            int x = leerEntero(scanner);
            
            System.out.print("Coordenada Y: ");
            int y = leerEntero(scanner);
            
            // Intentar mover la moto a las coordenadas especificadas
            boolean resultado = gestorVehiculos.moverMotoANuevasPosicion(idVehiculo, x, y);
            
            if (resultado) {
                System.out.println("Moto movida exitosamente del almacén a la posición (" +  
                                 x + ", " + y + ") en el mapa.");
                      
                // Mostrar el mapa actualizado
                Mapa mapa = Mapa.getInstancia();
                mapa.dibujarMapa();
            } else {
                System.out.println("No se pudo mover la moto a la posición especificada.");
            }
        } 
        else if (vehiculo instanceof VehiculoDeBase) {
            // Para bicicletas y patinetes, solicitar la base de destino
            System.out.println("Este vehículo es una " + vehiculo.getTipoVehiculo() + 
                             ". Debe ser asignado a una base.");
            
            // Mostrar bases disponibles
            Mapa mapa = Mapa.getInstancia();
            List<Base> bases = mapa.getBases();
            
            if (bases.isEmpty()) {
                System.out.println("No hay bases disponibles en el sistema.");
                return;
            }
            
            System.out.println("\nBases disponibles:");
            for (Base base : bases) {
                System.out.println("- " + base.getNombre() + 
                                 " (Coordenadas: " + base.getCoordenadaX() + ", " + base.getCoordenadaY() + 
                                 ", Espacios libres: " + base.getEspaciosLibres() + ")");
            }
            
            // Solicitar el nombre de la base de destino
            System.out.print("\nIntroduce el nombre de la base donde mover el vehículo: ");
            scanner.nextLine(); // Limpiar buffer
            String nombreBase = scanner.nextLine();
            
            // Intentar mover el vehículo a la base especificada
            boolean resultado = gestorVehiculos.moverVehiculoANuevaBase(idVehiculo, nombreBase);
            
            if (resultado) {
                System.out.println("Vehículo movido exitosamente del almacén a la base '" + nombreBase + "'.");
            } else {
                System.out.println("No se pudo mover el vehículo a la base especificada.");
            }
        } 
        else {
            System.out.println("Tipo de vehículo no reconocido. No se puede reubicar.");
        }
    }

    //=================================================
    // GESTIÓN DE BASES
    //=================================================
    
    private void altaBase() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n--- Alta de Base Manual ---");
        
        // Obtener una instancia del mapa
        Mapa mapa = Mapa.getInstancia();
        
        // Solicitar información de la nueva base
        System.out.print("Introduce el nombre de la base: ");
        String nombreBase = scanner.nextLine();
        
        // Verificar si ya existe una base con ese nombre
        if (mapa.getBasePorNombre(nombreBase) != null) {
            System.out.println("Error: Ya existe una base con el nombre '" + nombreBase + "'.");
            return;
        }
        
        // Solicitar coordenadas
        System.out.print("Introduce la coordenada X: ");
        int coordX = leerEntero(scanner);
        
        System.out.print("Introduce la coordenada Y: ");
        int coordY = leerEntero(scanner);
        
        // Verificar si las coordenadas son válidas y no están ocupadas
        if (!mapa.esCoordenadaValida(coordX, coordY)) {
            System.out.println("Error: Las coordenadas (" + coordX + ", " + coordY + 
                              ") están fuera de los límites del mapa.");
            return;
        }
        
        if (mapa.posicionOcupada(coordX, coordY)) {
            System.out.println("Error: La posición (" + coordX + ", " + coordY + 
                              ") ya está ocupada por otro elemento.");
            return;
        }
        
        // Solicitar capacidad
        System.out.print("Introduce la capacidad de la base: ");
        int capacidad = leerEntero(scanner);
        
        // Validar que la capacidad sea positiva
        if (capacidad <= 0) {
            System.out.println("Error: La capacidad debe ser un número positivo.");
            return;
        }
        
        // Añadir la base utilizando el método addBase de Mapa
        boolean resultado = mapa.addBase(nombreBase, coordX, coordY, capacidad);
        
        if (resultado) {
            System.out.println("Base '" + nombreBase + "' creada correctamente en coordenadas (" 
                    + coordX + ", " + coordY + ") con capacidad para " + capacidad + " vehículos.");
                        
            // Mostrar el mapa actualizado
            mapa.dibujarMapa();
        } else {
            System.out.println("Error al crear la base. Verifica que todos los datos sean correctos.");
        }
    }

    private void altaBaseAutomatica(Scanner scanner) {
        System.out.println("\n--- Alta de Base Automática ---");
        
        // Obtener una instancia del mapa
        Mapa mapa = Mapa.getInstancia();
        
        // Solicitar información de la nueva base
        System.out.print("Introduce el nombre de la base: ");
        String nombreBase = scanner.nextLine();
        
        // Verificar si ya existe una base con ese nombre
        if (mapa.getBasePorNombre(nombreBase) != null) {
            System.out.println("Error: Ya existe una base con el nombre '" + nombreBase + "'.");
            return;
        }

        // Solicitar capacidad
        System.out.print("Introduce la capacidad de la base: ");
        int capacidad = leerEntero(scanner);
        
        // Validar que la capacidad sea positiva
        if (capacidad <= 0) {
            System.out.println("Error: La capacidad debe estar entre 0 y 100 por ciento.");
            return;
        }

        int[] posicionOptima = mapa.encontrarPosicionMenosDensaBases();
        int coordX = posicionOptima[0];
        int coordY = posicionOptima[1];
        
        // Añadir la base utilizando el método addBase de Mapa
        boolean resultado = mapa.addBase(nombreBase, coordX, coordY, capacidad);
        
        if (resultado) {
            System.out.println("Base '" + nombreBase + "' creada correctamente en coordenadas (" 
                    + coordX + ", " + coordY + ") con capacidad para " + capacidad + " vehículos.");
                        
            // Mostrar el mapa actualizado
            mapa.dibujarMapa();
        } else {
            System.out.println("Error al crear la base. Verifica que todos los datos sean correctos.");
        }
    }

    private void dibujarMapa(Scanner scanner) {
        Mapa mapa = Mapa.getInstancia();
        mapa.dibujarMapa();
    }

    //=================================================
    // GESTIÓN DE VIAJES Y TARIFAS
    //=================================================
    
    private void modificarTarifa(Scanner scanner) {
        System.out.println("\n--- Modificación de tarifa ---");
        
        // Mostrar las tarifas actuales antes de preguntar cuál modificar
        System.out.println("\nTarifas actuales:");
        for (VehiculoEnum tipo : VehiculoEnum.values()) {
            double tarifa = Tarifas.obtenerTarifa(tipo);
            System.out.printf("%s: %.2f€ por hora\n", tipo, tarifa);
        }
        
        // Solicitar el tipo de vehículo a modificar
        System.out.print("\nSelecciona el vehículo cuya tarifa se va a modificar: ");
        VehiculoEnum tipoVehiculo = seleccionarTipoVehiculo(scanner);
        
        // Mostrar la tarifa actual del vehículo seleccionado
        double tarifaActual = Tarifas.obtenerTarifa(tipoVehiculo);
        System.out.printf("La tarifa actual para %s es: %.2f€ por hora\n", tipoVehiculo, tarifaActual);
        
        // Solicitar la nueva tarifa
        System.out.print("Introduce la nueva tarifa en euros por hora: ");
        double nuevaTarifa = leerDouble(scanner);
           
        // Actualizar la tarifa
        boolean resultado = gestorViajes.modificarTarifa(tipoVehiculo, nuevaTarifa);
        
        if (!resultado) {
            System.out.println("No se pudo modificar la tarifa. Asegúrate de que el valor sea válido.");
        }
    }

    private void modificarDescuento(Scanner scanner) {
        System.out.println("\n--- Modificación de descuento ---");
        
        // Mostrar los descuentos actuales antes de preguntar cuál modificar
        System.out.println("\nDescuentos actuales:");
        for (VehiculoEnum tipo : VehiculoEnum.values()) {
            double descuento = Descuentos.obtenerDescuento(tipo);
            System.out.printf("%s: %.0f%%\n", tipo, descuento);
        }
        
        // Solicitar el tipo de vehículo a modificar
        System.out.print("\nSelecciona el vehículo cuyo descuento se va a modificar: ");
        VehiculoEnum tipoVehiculo = seleccionarTipoVehiculo(scanner);
        
        // Mostrar el descuento actual del vehículo seleccionado
        double descuentoActual = Descuentos.obtenerDescuento(tipoVehiculo);
        System.out.printf("El descuento actual para %s es: %.0f%%\n", tipoVehiculo, descuentoActual);
        
        // Solicitar el nuevo descuento
        System.out.print("Introduce el nuevo descuento en %: ");
        double nuevoDescuento = leerDouble(scanner);
        
        // Verificar que el descuento esté en el rango válido (0-100)
        if (nuevoDescuento < 0 || nuevoDescuento > 100) {
            System.out.println("Error: El descuento debe estar entre 0 y 100 por ciento.");
            return;
        }
           
        // Actualizar el descuento
        boolean resultado = gestorViajes.modificarDescuento(tipoVehiculo, nuevoDescuento);
        
        if (!resultado) {
            System.out.println("No se pudo modificar el descuento. Asegúrate de que el valor sea válido.");
        }
    }

    private void modificarReservas(Scanner scanner) {
        System.out.println("\n--- Modificación de reservas ---");
        
        // Mostrar el estado actual de las reservas
        boolean estadoActual = Beneficios.sePuedeReservar();
        System.out.println("Estado actual: Las reservas están " + 
                          (estadoActual ? "HABILITADAS" : "DESHABILITADAS") + ".");
        
        // Ofrecer la opción de cambiar al estado contrario
        System.out.println("¿Qué deseas hacer?");
        if (estadoActual) {
            System.out.print("¿Deseas deshabilitar las reservas? (1: Sí, 2: No): ");
            int opcion = leerEntero(scanner);
            if (opcion == 1) {
                Beneficios.definirSePuedeReservar(false);
                System.out.println("Las reservas han sido deshabilitadas correctamente.");
            } else {
                System.out.println("No se han realizado cambios. Las reservas siguen habilitadas.");
            }
        } else {
            System.out.print("¿Deseas habilitar las reservas? (1: Sí, 2: No): ");
            int opcion = leerEntero(scanner);
            if (opcion == 1) {
                Beneficios.definirSePuedeReservar(true);
                System.out.println("Las reservas han sido habilitadas correctamente.");
            } else {
                System.out.println("No se han realizado cambios. Las reservas siguen deshabilitadas.");
            }
        }
    }

    private void modificarBaterias(Scanner scanner) {
        System.out.println("\n--- Modificación de batería ---");
        System.out.print("¿Deseas habilitar o deshabilitar la batería premium? (1: Habilitar, 2: Deshabilitar): ");
        int opcion = leerEntero(scanner);
        if (opcion == 1) {
            Beneficios.definirBateriaPremiumPermitida(true);
            System.out.println("La batería premium ha sido habilitada correctamente.");
        } else if (opcion == 2) {
            Beneficios.definirBateriaPremiumPermitida(false);
            System.out.println("La batería premium ha sido deshabilitada correctamente.");
        } else {
            System.out.println("Opción no válida. Por favor, selecciona 1 o 2.");
        }
    }

    //=================================================
    // GESTIÓN DE EMPLEADOS
    //=================================================
    
    public void asignarVehiculoMantenimiento(Scanner scanner) {
        System.out.println("\n=== ASIGNAR VEHÍCULOS A MANTENIMIENTO ===");
        
        // Mostrar personal de mantenimiento disponible
        System.out.println("\nPersonal de mantenimiento disponible:");
        boolean hayPersonal = false;
        for (Persona persona : gestorPersonas.getPersonas()) {
            if (persona.getRol() == RolEnum.MANTENIMIENTO) {
                System.out.printf("DNI: %s - %s %s\n", 
                    persona.getDNI(), persona.getNombre(), persona.getApellidos());
                hayPersonal = true;
            }
        }
        
        if (!hayPersonal) {
            System.out.println("No hay personal de mantenimiento registrado en el sistema.");
            return;
        }
        
        System.out.print("\nIntroduce el DNI del personal de mantenimiento: ");
        String dniInput = scanner.next();
        // resto del código...
    }

    public void asignarVehiculoMecanico(Scanner scanner) {
        System.out.println("\n=== ASIGNAR VEHÍCULOS A MECÁNICO ===");
        
        System.out.print("Introduce el DNI del mecánico (8 números seguidos de una letra mayúscula): ");
        String dniInput = scanner.next();
        
        // Formatear el DNI
        String dni = formatearDNI(dniInput);
        if (dni == null) {
            System.out.println("Error: Formato de DNI incorrecto. Debe contener 8 dígitos y una letra.");
            return;
        }
        
        // Verificar que la persona existe y tiene el rol correcto
        if (!gestorPersonas.existeDNI(dni)) {
            System.out.println("Error: No existe ninguna persona con el DNI proporcionado.");
            return;
        }
        
        if (gestorPersonas.getRolPersona(dni) != RolEnum.MECANICO) {
            System.out.println("Error: La persona con DNI " + dni + 
                              " no tiene el rol de MECÁNICO.");
            return;
        }
        
        // Asignar vehículos que necesitan reparación al mecánico
        System.out.println("Asignando vehículos con averías del almacén al mecánico...");
        var vehiculosAsignados = gestorVehiculos.asignarVehiculoMecanico(dni);
        
        if (vehiculosAsignados.isEmpty()) {
            System.out.println("No hay vehículos en el almacén que requieran reparación en este momento.");
        } else {
            System.out.println("\nSe han asignado " + vehiculosAsignados.size() + 
                              " vehículos al mecánico con DNI: " + dni);
            System.out.println("IDs de vehículos asignados: " + vehiculosAsignados);
        }
    }

    public void asignarBaseMecanico(Scanner scanner) {
        System.out.println("\n=== ASIGNAR BASE CON FALLOS A MECÁNICO ===");
        
        System.out.print("Introduce el DNI del mecánico (8 números seguidos de una letra mayúscula): ");
        String dniInput = scanner.next();
        
        // Formatear el DNI
        String dni = formatearDNI(dniInput);
        if (dni == null) {
            System.out.println("Error: Formato de DNI incorrecto. Debe contener 8 dígitos y una letra.");
            return;
        }
        
        // Verificar que la persona existe y tiene el rol correcto
        if (!gestorPersonas.existeDNI(dni)) {
            System.out.println("Error: No existe ninguna persona con el DNI proporcionado.");
            return;
        }
        
        if (gestorPersonas.getRolPersona(dni) != RolEnum.MECANICO) {
            System.out.println("Error: La persona con DNI " + dni + 
                              " no tiene el rol de MECÁNICO.");
            return;
        }
        
        // Obtener el Mapa para buscar bases con fallos
        Mapa mapa = Mapa.getInstancia();
        boolean hayBasesConFallos = false;
        
        System.out.println("\nBases con fallos:");
        for (var base : mapa.getBases()) {
            if (base.tieneAverias(false)) { // Consultar sin actualizar el estado
                System.out.println("- Base " + base.getNombre() + 
                                  " (Coords: " + base.getCoordenadaX() + ", " + base.getCoordenadaY() + ")");
                hayBasesConFallos = true;
            }
        }
        
        if (!hayBasesConFallos) {
            System.out.println("No se encontraron bases con fallos.");
            return;
        }
        
        // Solicitar el nombre de la base a asignar
        System.out.print("\nIntroduce el nombre de la base a asignar: ");
        scanner.nextLine(); // Limpiar el buffer
        String nombreBase = scanner.nextLine();
        
        // Verificar que la base existe
        var base = mapa.getBasePorNombre(nombreBase);
        if (base == null) {
            System.out.println("Error: No existe una base con el nombre '" + nombreBase + "'.");
            return;
        }
        
        // Verificar que la base tiene averías
        if (!base.tieneAverias(false)) {
            System.out.println("La base '" + nombreBase + "' no tiene fallos registrados.");
            return;
        }
                
        // Asignar la base al mecánico
        System.out.println("Base '" + nombreBase + "' asignada al mecánico con DNI: " + dni + 
                          " para su reparación.");
            
        // Aquí se podría registrar la asignación en alguna estructura de datos o sistema
    }

    //=================================================
    // CONSULTAS Y VISUALIZACIÓN
    //=================================================
    
    private void mostrarPersonas(Scanner scanner) {
        gestorPersonas.mostrarPersonas();
    }

    private void mostrarVehiculos(Scanner scanner) {
        gestorVehiculos.mostrarVehiculos();
    }

    private void mostrarBases(Scanner scanner) {
        Mapa mapa = Mapa.getInstancia();
        mapa.mostrarBases();
    }

    private void mostrarViajes() {
        gestorViajes.mostrarViajes();
    }

    private void visualizarEstadoVehiculos(Scanner scanner) {
        System.out.println("\n=== ESTADO DE VEHÍCULOS ===");
        
        List<Vehiculo> todosLosVehiculos = new ArrayList<>();
        todosLosVehiculos.addAll(gestorVehiculos.getVehiculosAlmacenados());
        todosLosVehiculos.addAll(gestorVehiculos.getVehiculosEnMapa());
        todosLosVehiculos.addAll(gestorVehiculos.getVehiculosEnBases());
        
        System.out.println("\n--- ESTADO DE BATERÍA Y AVERÍAS ---");
        System.out.printf("%-5s %-15s %-10s %-15s %-20s\n", 
                        "ID", "Tipo", "Batería", "Averías", "Ubicación");
        System.out.println("------------------------------------------------------------");
        
        for (Vehiculo vehiculo : todosLosVehiculos) {
            String ubicacion;
            if (gestorVehiculos.getVehiculosAlmacenados().contains(vehiculo)) {
                ubicacion = "Almacén";
            } else if (gestorVehiculos.getVehiculosEnMapa().contains(vehiculo)) {
                ubicacion = "Mapa (" + vehiculo.getCoordenadaX() + "," + vehiculo.getCoordenadaY() + ")";
            } else {
                if (vehiculo instanceof VehiculoDeBase) {
                    Base base = ((VehiculoDeBase) vehiculo).getBase();
                    ubicacion = base != null ? "Base: " + base.getNombre() : "Sin base";
                } else {
                    ubicacion = "Desconocida";
                }
            }
               
            System.out.printf("%-5d %-15s %-10s %-15s %-20s\n", 
                        vehiculo.getID(),
                        vehiculo.getTipoVehiculo(),
                        vehiculo.getBateria() + "%",
                        vehiculo.tieneAverias() ? "SÍ" : "NO",
                        ubicacion);
        }
    }

    private void visualizarEstadoBases(Scanner scanner) {
        System.out.println("\n=== ESTADO DE BASES ===");
        
        Mapa mapa = Mapa.getInstancia();
        List<Base> bases = mapa.getBases();
        
        if (bases.isEmpty()) {
            System.out.println("No hay bases registradas en el sistema.");
            return;
        }
        
        System.out.println("\n--- ESTADO DE BASES ---");
        System.out.printf("%-15s %-15s %-15s %-15s %-15s\n", 
                        "Nombre", "Coordenadas", "Capacidad", "Ocupación", "Averías");
        System.out.println("-----------------------------------------------------------------------");
        
        for (Base base : bases) {
            int capacidad = base.getCapacidad();
            int ocupados = capacidad - base.getEspaciosLibres();
            int porcentajeOcupacion = (ocupados * 100) / Math.max(1, capacidad);
            
            System.out.printf("%-15s (%2d,%-2d)       %-15d %-15s %-15s\n", 
                        base.getNombre(),
                        base.getCoordenadaX(),
                        base.getCoordenadaY(),
                        capacidad,
                        ocupados + "/" + capacidad + " (" + porcentajeOcupacion + "%)",
                        base.tieneAverias(false) ? "SÍ" : "NO");
        }
        
        System.out.println("\n--- VEHÍCULOS EN BASES ---");
        for (Base base : bases) {
            System.out.println("\nBase: " + base.getNombre());
            List<Vehiculo> vehiculosEnBase = base.getVehiculos();
            
            if (vehiculosEnBase.isEmpty()) {
                System.out.println("  No hay vehículos en esta base.");
            } else {
                System.out.printf("  %-5s %-15s %-10s %-10s\n", 
                            "ID", "Tipo", "Batería", "Averías");
                System.out.println("  ----------------------------------------");
                
                for (Vehiculo vehiculo : vehiculosEnBase) {
                    System.out.printf("  %-5d %-15s %-10s %-10s\n",
                                vehiculo.getID(),
                                vehiculo.getTipoVehiculo(),
                                vehiculo.getBateria() + "%",
                                vehiculo.tieneAverias() ? "SÍ" : "NO");
                }
            }
        }
    }

    private void visualizarEstadisticasUso(Scanner scanner) {
        System.out.println("\n=== ESTADÍSTICAS DE USO DE VEHÍCULOS ===");
        System.out.println("1. Viajes por tipo de vehículo");
        System.out.println("2. Ingresos por tipo de vehículo");
        System.out.println("3. Bases con mayor/menor demanda");
        System.out.println("4. Vehículos en uso actualmente");
        System.out.println("5. Volver al menú anterior");
        
        System.out.print("\nSeleccione una opción: ");
        int opcion = leerEntero(scanner);
        
        switch (opcion) {
            case 1:
                mostrarViajesPorTipoVehiculo();
                break;
            case 2:
                mostrarIngresosPorTipoVehiculo();
                break;
            case 3:
                mostrarEstadisticasBases();
                break;
            case 4:
                mostrarVehiculosEnUso();
                break;
            case 5:
                return;
            default:
                System.out.println("Opción no válida.");
        }
    }

    private void mostrarViajesPorTipoVehiculo() {
        System.out.println("\n--- VIAJES POR TIPO DE VEHÍCULO ---");
        
        Map<VehiculoEnum, Integer> viajesPorTipo = gestorViajes.obtenerViajesPorTipoVehiculo();
        
        if (viajesPorTipo.isEmpty()) {
            System.out.println("No hay datos de viajes registrados.");
            return;
        }
        
        System.out.printf("%-15s %-10s %-10s\n", "Tipo Vehículo", "Viajes", "Porcentaje");
        System.out.println("----------------------------------------");
        
        int totalViajes = viajesPorTipo.values().stream().mapToInt(Integer::intValue).sum();
        
        for (Map.Entry<VehiculoEnum, Integer> entry : viajesPorTipo.entrySet()) {
            double porcentaje = (entry.getValue() * 100.0) / totalViajes;
            System.out.printf("%-15s %-10d %.2f%%\n", entry.getKey(), entry.getValue(), porcentaje);
        }
        
        System.out.println("----------------------------------------");
        System.out.println("Total viajes: " + totalViajes);
    }

    private void mostrarIngresosPorTipoVehiculo() {
        System.out.println("\n--- INGRESOS POR TIPO DE VEHÍCULO ---");
        
        Map<VehiculoEnum, Double> ingresosPorTipo = gestorViajes.obtenerIngresosPorTipoVehiculo();
        
        if (ingresosPorTipo.isEmpty()) {
            System.out.println("No hay datos de ingresos registrados.");
            return;
        }
        
        System.out.printf("%-15s %-15s %-10s\n", "Tipo Vehículo", "Ingresos (€)", "Porcentaje");
        System.out.println("-------------------------------------------");
        
        double totalIngresos = ingresosPorTipo.values().stream().mapToDouble(Double::doubleValue).sum();
        
        for (Map.Entry<VehiculoEnum, Double> entry : ingresosPorTipo.entrySet()) {
            double porcentaje = (entry.getValue() * 100.0) / totalIngresos;
            System.out.printf("%-15s €%-14.2f %.2f%%\n", entry.getKey(), entry.getValue(), porcentaje);
        }
        
        System.out.println("-------------------------------------------");
        System.out.printf("Total ingresos: €%.2f\n", totalIngresos);
    }

    private void mostrarEstadisticasBases() {
        System.out.println("\n--- ESTADÍSTICAS DE BASES ---");
        
        Map<String, Integer> viajesPorBase = gestorViajes.obtenerViajesPorBase();
        if (viajesPorBase.isEmpty()) {
            System.out.println("No hay datos de viajes por base registrados.");
            return;
        }
        
        List<Map.Entry<String, Integer>> basesPorDemanda = new ArrayList<>(viajesPorBase.entrySet());
        basesPorDemanda.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));
        
        System.out.println("\nBases ordenadas por demanda (mayor a menor):");
        System.out.printf("%-20s %-10s\n", "Nombre Base", "Viajes");
        System.out.println("--------------------------------");
        
        for (Map.Entry<String, Integer> entry : basesPorDemanda) {
            System.out.printf("%-20s %-10d\n", entry.getKey(), entry.getValue());
        }
        
        if (!basesPorDemanda.isEmpty()) {
            System.out.println("\nBase con MAYOR demanda: " + basesPorDemanda.get(0).getKey() + 
                               " (" + basesPorDemanda.get(0).getValue() + " viajes)");
            
            System.out.println("Base con MENOR demanda: " + basesPorDemanda.get(basesPorDemanda.size() - 1).getKey() + 
                               " (" + basesPorDemanda.get(basesPorDemanda.size() - 1).getValue() + " viajes)");
        }
    }

    private void mostrarVehiculosEnUso() {
        System.out.println("\n--- VEHÍCULOS EN USO ACTUALMENTE ---");
        
        List<Vehiculo> vehiculosEnUso = gestorViajes.obtenerVehiculosEnUsoActual();
        
        if (vehiculosEnUso.isEmpty()) {
            System.out.println("No hay vehículos en uso actualmente.");
            return;
        }
        
        System.out.printf("%-5s %-15s %-20s %-20s\n", 
                        "ID", "Tipo", "Usuario", "Inicio del viaje");
        System.out.println("----------------------------------------------------------");
        
        for (Vehiculo vehiculo : vehiculosEnUso) {
            String datosViaje = gestorViajes.obtenerDatosViajeActual(vehiculo.getID());
            System.out.println(datosViaje);
        }
    }
    
    //=================================================
    // MÉTODOS AUXILIARES
    //=================================================
    
    private int leerEntero(Scanner scanner) {
        while (true) {
            try {
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Error: Por favor, introduce un número válido.");
                scanner.next(); // Limpiar entrada no válida
            }
        }
    }

    private RolEnum seleccionarRol(Scanner scanner) {
        while (true) {
            System.out.println("Introduce el rol del nuevo registro:");
            System.out.println("1. Usuario");
            System.out.println("2. Mecánico");
            System.out.println("3. Mantenimiento");
            System.out.println("4. Administrador");
            System.out.print("Selecciona una opción (1-4): ");

            int opcion = leerEntero(scanner);
            return switch (opcion) {
                case 1 -> RolEnum.USUARIO_STANDARD;
                case 2 -> RolEnum.MECANICO;
                case 3 -> RolEnum.MANTENIMIENTO;
                case 4 -> RolEnum.ADMINISTRADOR;
                default -> {
                    System.out.println("Opción no válida. Por favor, selecciona una opción del 1 al 4.");
                    yield null;
                }
            };
        }
    }

    private VehiculoEnum seleccionarTipoVehiculo(Scanner scanner) {
        while (true) {
            System.out.println("Selecciona el tipo de vehículo:");
            System.out.println("1. Moto Pequeña");
            System.out.println("2. Moto Grande");
            System.out.println("3. Bicicleta");
            System.out.println("4. Patinete");
            System.out.print("Introduce una opción (1-4):");

            int opcion = leerEntero(scanner);
            return switch (opcion) {
                case 1 -> VehiculoEnum.MOTOPEQUENA;
                case 2 -> VehiculoEnum.MOTOGRANDE;
                case 3 -> VehiculoEnum.BICICLETA;
                case 4 -> VehiculoEnum.PATINETE;
                default -> {
                    System.out.println("Opción no válida. Por favor, selecciona una opción del 1 al 4.");
                    yield null;
                }
            };
        }
    }
    
    private String formatearDNI(String dniInput) {
        if (dniInput == null || dniInput.isEmpty()) {
            return null;
        }
        
        String dniLimpio = dniInput.replaceAll("[^0-9a-zA-Z]", "");
        
        if (dniLimpio.length() < 9) {
            return null;
        }
        
        String parteNumerica = dniLimpio.substring(0, 8);
        
        if (!parteNumerica.matches("^\\d+$")) {
            return null;
        }
        
        char letra = Character.toUpperCase(dniLimpio.charAt(8));
                
        if (!Character.isLetter(letra)) {
            return null;
        }
        
        return parteNumerica + letra;
    }

    private double leerDouble(Scanner scanner) {
        while (true) {
            try {
                return scanner.nextDouble();
            } catch (InputMismatchException e) {
                System.out.println("Error: Por favor, introduce un número válido.");
                scanner.next(); // Limpiar entrada no válida
            }
        }
    }

    private String determinarUbicacionVehiculo(Vehiculo vehiculo) {
        if (gestorVehiculos.getVehiculosAlmacenados().contains(vehiculo)) {
            return "Almacén";
        } else if (gestorVehiculos.getVehiculosEnMapa().contains(vehiculo)) {
            return "Mapa (" + vehiculo.getCoordenadaX() + "," + vehiculo.getCoordenadaY() + ")";
        } else {
            if (vehiculo instanceof VehiculoDeBase) {
                Base base = ((VehiculoDeBase) vehiculo).getBase();
                return base != null ? "Base: " + base.getNombre() : "Sin base";
            } else {
                return "Desconocida";
            }
        }
    }
}
